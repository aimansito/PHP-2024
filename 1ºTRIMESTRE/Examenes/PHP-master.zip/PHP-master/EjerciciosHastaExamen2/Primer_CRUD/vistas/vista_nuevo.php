<?php
echo "<form action='usuario_nuevo.php' method='post'>";
echo "<p><button type='submit' name='btnNuevoUsuario'>Insertar nuevo Usuario</button></p>";
echo "</form>";
?>