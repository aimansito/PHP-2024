<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        //ej4
        echo "<h3>Ejercicio 4: </h3> ";
        $arr4[]="Pedro";
        $arr4[]="Ana";
        $arr4[]=1;

        print_r($arr4);
        echo "--------------"."</br>";
    ?>
</body>
</html>