<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <H1>Teoria de fechas</H1>
    <?php
        echo "<p>"-Time()."</p>";
        $fecha=date("",1702944000);
    ?>
</body>
</html>